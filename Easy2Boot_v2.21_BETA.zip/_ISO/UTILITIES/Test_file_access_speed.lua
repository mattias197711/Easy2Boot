-- this file is can be run from grub2 agFM only
-- https://a1ive.github.io/grub2_lua_zh.html

function getfile ()
  local line = ""
  in_file = grub.file_open ("(hd0,2)/efi/boot/bootx64.efi")
  grub.file_getsize (in_file)
  grub.file_seek (in_file, 0)
  while (grub.file_eof (in_file) ~= true)
  do
    line = grub.file_getline (in_file)
  end
  grub.file_close (in_file)
end


--print("Starting 1000 file accesses...")
--line = input.read ()
x = os.clock()
for i=1,500 do 
	grub.file_exist ("(hd0,1)/menu.lst")
	grub.file_exist ("(hd0,2)/efi/boot/bootx64.efi")
end
print("Time for 1000 file accesses: ", (os.clock() - x) / 1000)
print("")
--grub.setenv("cputime",(os.clock() - x) / 1000)

print("Press 1 and ENTER to run 10,000 file accesses")
print("or ENTER to finish")
line = input.read ()
if ( line == "1" )
	then
	--print ("\nStarting 10,000 file accesses\n")
	x = os.clock()
	for i=1,5000 do 
		grub.file_exist ("(hd0,1)/menu.lst")
		grub.file_exist ("(hd0,2)/efi/boot/bootx64.efi")
	end
	print("\nTime for 10,000 file accesses: ", (os.clock() - x) / 1000)
	print("")
	print("Press ENTER to finish")
	line = input.read ()
end
