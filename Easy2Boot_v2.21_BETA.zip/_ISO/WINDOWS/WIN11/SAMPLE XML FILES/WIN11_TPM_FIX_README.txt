REM To disable the Win11 TPM 2.0, RAM size and Secure Boot checks
REM Make a copy of this file
REM Rename the new file to have the same filename as the Windows 11 ISO, but with a .cmd file extension
REM e.g.
REM \_ISO\WINDOWS\WIN11\Windows_11_x64_Pro.iso
REM \_ISO\WINDOWS\WIN11\Windows_11_x64_Pro.cmd

reg add "HKLM\SYSTEM\Setup\LabConfig" /v "BypassTPMCheck" /t REG_DWORD /d 1
reg add "HKLM\SYSTEM\Setup\LabConfig" /v "BypassRAMCheck" /t REG_DWORD /d 1
reg add "HKLM\SYSTEM\Setup\LabConfig" /v "BypassSecureBootCheck" /t REG_DWORD /d 1

