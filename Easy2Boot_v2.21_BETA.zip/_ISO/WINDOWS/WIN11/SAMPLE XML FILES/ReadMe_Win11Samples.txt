The Windows 10 Sample files will also work for Windows 11.
Windows 11 uses the same Product Keys as Windows 11.
Most XML settings are identical to Windows 10.

So you can also the files at \_ISO\WINDOWS\WIN10\SAMPLE XML FILES

