Sample XML files

Most of the 'wipe disk' XML files are for Legacy\MBR booting and make MBR partitions.
One example 'wipe disk' XML file example is for UEFI - ZZDANGER_Auto_WipeDisk0_Win10Pro_UEFI64_max_ptn_USA_SDI_CHOCO.xml
That XML file make GPT partitions.

Most Win10 XML files will also work with Win11 ISOs.

You can easily create your own XML file using the XMLtoE2B utility (see website).

eBook #1 and eBook #2 contain full information and exercises.


