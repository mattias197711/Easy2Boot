Some AIO ISO files may not work as they do not contain standard Microsoft boot files.

In this case do not allow E2B to use WIMBOOT.

When E2B prompts you to press ENTER quickly to not use WIMBOOT, then press ENTER key.

   'Windows Install ISO detected - booting using WIMBOOT'
   'Press ENTER quickly if you do NOT want to use WIMBOOT...'

If the Windows ISO boots correctly then you can change the filename of the ISO so that it
always skips wimboot by adding the characters 'NOWIMBOOT' to the filename, e.g.

\_ISO\WINDOWS\WINAIO\Windows_AIO_NOWIMBOOT.iso

Also, you can try the Ventoy menu system instead of the E2B or agFM menu system.