Place the whole wsusoffline folder here.

see http://download.wsusoffline.net/

startup.cmd will try to run either 
USB:\_ISO\WINDOWS\INSTALLS\wsusoffline\client\cmd\DoUpdate.cmd
or
C:\DRIVERS\wsusoffline\client\cmd\DoUpdate.cmd

WSUS must be run as Administrator.