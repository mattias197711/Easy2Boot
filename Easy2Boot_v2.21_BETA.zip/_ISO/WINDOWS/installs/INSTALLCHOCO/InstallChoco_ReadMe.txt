InstallChoco.cmd
================

https://easy2boot.xyz/create-your-website-with-blocks/add-payload-files/windows-install-isos/installing-offline-chocolatey-packages/

Offline install of Chocolatey.

You need to add the Chocolatey package for Chocolatey itself to this folder:

1. Run \_ISO\docs\ChocBox\ChocBox.cmd
2. Make a Chocolatey package (press ENTER for latest version)
3. Copy the C:\DRIVERS\CHOCBOX\Chocolatey*.nupkg file to USB:\_ISO\WINDOWS\INSTALLS\INSTALLCHOCO\chocolatey.nupkg

See other README file for Win7 + Choco install information.

Action of Scripts
=================

InstallChoco.cmd runs installchoco.ps1
InstallChoco.ps1 installs Chocolatey.nupkg to C:\ProgramData\Chocolatey folder and adds to Path environment variable so that choco commands can be run

If Chocolatey folder already exists, then it will not be re-installed.
