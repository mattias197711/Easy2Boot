.Net 4.5.2 OFFLINE DOWNLOAD IS REQUIRED

Add file NDP452-KB2901907-x86-x64-AllOS-ENU.exe to INSTALLCHOCO folder for Win7 + CHOCO

Note: .Net 4.8 may not install on Vanilla Win7.

DOWNLOAD: 
4.5.2 https://go.microsoft.com/fwlink/?LinkId=397708

If 4.5 or 4.8 is already in Win7 ISO image then the .exe will not be installed.