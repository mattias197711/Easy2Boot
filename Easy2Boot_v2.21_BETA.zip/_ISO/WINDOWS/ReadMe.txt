If you have Windows XP, Vista, Win7, Win8, SVR2K8R2, SVR2012, Win10, SVR2016, SVR2019, All-In-One install .ISO files then copy them to the appropriate folder.

DO NOT COPY .ISO files to the \_ISO\WINDOWS folder - they will not be found by E2B!

You must copy Windows Installer ISOs to the correct sub-folder (3rd level)...

\_ISO\WINDOWS\XP                          - Windows XP Installer .ISO files (.imgPTN* files are NOT supported)
\_ISO\WINDOWS\VISTA, WIN7, SVR2K8R2, etc. - Windows Installer .ISO and .imgPTN* files are supported

.imgPTN files are not supported in the \_ISO\WINDOWS\XP folder - only add Windows XP Install .ISO files to this folder.

You can also add you own unattend.xml files and Product Key files.

See https://easy2boot.xyz/create-your-website-with-blocks/add-payload-files/windows-install-isos/xmltoe2b/

Sample XML files are in the SAMPLE XML FILES folder. Copy them to the same folder as your ISO files if you want to use them.

Windows 8.1 and later versions of Windows will usually require you to choose or specify the correct Product Key in the XML file.

If you copy a DEFAULT.XML file to the same folder, it will be automatically be used (you can still press ENTER to load a different XML or KEY file). e.g. copy No key (choose a version to install).xml to DEFAULT.xml.

UtilMan XML files
=================
The Windows 10 UtilMan XML files allow you to hack an existing Windows OS to gain access.
Boot to a Win8/10 install ISO and pick the 'Utilman - Hack Windows (patch UtilMan.exe).xml' file.

See \_ISO\docs\UtilMan\ReadMe.txt for details.

See the www.easy2boot.xyz website for more details on Easy2Boot.