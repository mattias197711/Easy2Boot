You must edit the STRINGS_ARABIC.txt and F1_ARABIC.cfg files.

DO NOT EDIT THE STRINGS.TXT file or F1.CFG file!

             STRINGS_ARABIC.txt ->  STRINGS_ARABIC.rev.txt ->  STRINGS.TXT

1. STRINGS_ARABIC.txt is the native Arabic file. Edit this file. Do NOT edit the STRINGS.txt file.

2. Convert STRINGS_ARABIC.txt to STRINGS_ARABICrev.txt  by drag-and-dro onto \_ISO\docs\E2B Utilities\Fribidi\Reverse.cmd

3. Rename STRINGS_ARABICrev.txt to STRINGS.txt

Repeat the process for F1_ARABIC.cfg  ->  F1_ARABICrev.cfg ->  F1.cfg
	     
See https://easy2boot.xyz/create-your-website-with-blocks/configure-e2b/right-to-left-languages/ for more information
