E2B Launcher is made using the free utility 'AutoPlay Menu Builder' from LinaSoft
http://www.linasoft.com/apmbuilder.php

You can download the APM Menu Builder and load the 'E2B Launcher.apm' and make your own Launcher application.

