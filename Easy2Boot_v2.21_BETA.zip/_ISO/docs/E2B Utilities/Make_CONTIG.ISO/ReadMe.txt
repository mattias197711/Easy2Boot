Makes a new \_ISO\CONTIG.ISO file of any size
