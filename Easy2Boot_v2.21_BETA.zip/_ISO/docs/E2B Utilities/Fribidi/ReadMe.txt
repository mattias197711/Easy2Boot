First unzip Fribidi.zip to Fribisi.exe in the same folder.

The password is fribidi

Drag-and-Drop a UTF-8 .mnu file or .txt file onto the Reverse.cmd file to create a new file.

e.g. Ubunturev.mnu will be made from Ubuntu.mnu

