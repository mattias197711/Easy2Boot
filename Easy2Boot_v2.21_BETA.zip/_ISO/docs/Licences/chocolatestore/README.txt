https://github.com/BahKoo/ChocolateStore
Apache licence - see LICENSE.txt
