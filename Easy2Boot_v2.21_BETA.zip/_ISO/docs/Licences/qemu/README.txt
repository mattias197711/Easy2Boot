https://wiki.qemu.org/License

QEMU is licensed under GPL v2

https://www.gnu.org/licenses/old-licenses/gpl-2.0.html