https://www.snappy-driver-installer.org/

GPLv3 - https://www.gnu.org/licenses/gpl-3.0.en.html



