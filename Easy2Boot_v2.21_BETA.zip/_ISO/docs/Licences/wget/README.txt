https://www.gnu.org/software/wget/

free software definition - https://www.gnu.org/philosophy/free-sw
