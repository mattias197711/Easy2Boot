lzma.exe and the SDK are free to use with no restriction and is in the Public Domain

https://www.7-zip.org/sdk.html

