GetWaikTools is an App to fast download the often needed deployment tools.
Included are the Wim driver to mount Wim files, imagex, wimgapi,
the BCD store tools, OSCDIMG to create ISO files and the DISM utility.

Commandline support:

-vista            windows Vista WAIK Tools
-win7             windows 7 WAIK Tools
-win8             windows 8 ADK Tools
-win8.1           windows 8.1 ADK Tools
-win10            windows 10 ADK Tools

-win7dism         windows 7 WAIK Dism Tools
-win8dism         windows 8 ADK Dism Tools
-win8.1dism       windows 8.1 ADK Dism Tools
-win10dism        windows 10 ADK Dism Tools

-all              all the above WAIK / ADK tools

-allextras        all the below other tools

-devcon           windows 8.1 devcon Tools

-windiff          WinDiff tool from Win7 SDK

-xpramboot        files required to boot PE1.x into RAM
-xpwimboot        files required for PE1.x WimBoot
-xpwinload        Vista RTM winload.exe, able to boot WinXP

-w2k3disk         Windows 2003 SP2 disk.sys

-xpcards          Windows 2003 SP2 cards.dll
-xpdiskcopy       Windows 2003 SP2 diskcopy.dll
-xppowercalc      PowerCalculator from XP Power Tools



-silent           suppress success or error messages
-folder:{dir}     location to download to
-ontop            set the ontop flag for the window

