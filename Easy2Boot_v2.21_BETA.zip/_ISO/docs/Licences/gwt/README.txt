gwt by JFX
https://msfn.org/board/topic/156869-get-waik-tools-wo-downloading-the-huge-isos/#comments

Not open source - free to use/distribute
