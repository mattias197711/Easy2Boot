Copy MyE2B.cfg from one of the Template folders to the \_ISO folder on your USB drive

Blue    - this uses an 800x600 blue background and a menu in the centre of the screen
GFXMenu - this is an example of a GFXMenu interface. You can make your own GFXMenu (message file)

Study the MyE2B.cfg file to see how they work.

See www.easy2boot.xyz for more details.

