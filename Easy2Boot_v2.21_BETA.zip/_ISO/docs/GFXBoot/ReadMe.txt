GFX Boot Menu
=============

For more info see https://easy2boot.xyz/create-your-website-with-blocks/configure-e2b/gfx-boot-menu/

To create and test a GFX Boot menu
==================================

1. Create \_ISO\MyE2B.cfg as below

!BAT
set GFX=docs/GFXBOOT/message

2. Double-click on \_ISO\docs\GFXBoot\repack.cmd to create a new message file

3. Boot E2B!



Changing the GFX Menu (\_ISO\docs\GFXBoot\files folder)
=======================================================

1. The wallpaper must be called back.jpg - change it to your desired 800x600 jpg

2. Edit the gfxboot.cfg file as required

3. Double-click on \_ISO\docs\GFXBoot\repack.cmd to create a new message file



