sed -i -e 's/\r$//'  fmt.sh
sudo ./fmt.sh

