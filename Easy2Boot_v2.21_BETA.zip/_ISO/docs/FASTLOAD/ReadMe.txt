To enable caching of the main menu and have a faster Main Menu load time,
Copy FASTLOAD.YES to the root of your USB boot drive.

To disable caching (FASTLOAD) either rename \FASTLOAD.YES to FASTLOAD.NO or delete it.

\FASTLOAD.YES should be over 1K in size and contain the single word REFRESH when first used.

Don't forget to press F8 in the Main Menu if you change any of the payload files on the E2B drive, otherwise
the Main Menu will not be changed!